// Supabase Edge Function for sending SMS notifications via Twilio
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { Twilio } from 'https://esm.sh/twilio@4.11.0';

// CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Parse request data
    const { to, body, from } = await req.json();

    // Validate required fields
    if (!to || !body) {
      return new Response(
        JSON.stringify({ 
          error: 'Missing required fields',
          details: 'The "to" and "body" fields are required.' 
        }),
        { 
          status: 400, 
          headers: { 
            'Content-Type': 'application/json',
            ...corsHeaders
          } 
        }
      );
    }

    // Get Twilio credentials from environment variables
    const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const authToken = Deno.env.get('TWILIO_AUTH_TOKEN');
    const twilioPhone = Deno.env.get('TWILIO_PHONE_NUMBER') || from;

    // Check if credentials are configured
    if (!accountSid || !authToken || !twilioPhone) {
      console.error('Twilio credentials not configured');
      return new Response(
        JSON.stringify({ 
          error: 'Configuration error',
          details: 'Twilio credentials are not properly configured.' 
        }),
        { 
          status: 500, 
          headers: { 
            'Content-Type': 'application/json',
            ...corsHeaders
          } 
        }
      );
    }

    // Initialize Twilio client
    const client = new Twilio(accountSid, authToken);

    // Format the phone number to E.164 format if needed
    const formattedNumber = to.startsWith('+') ? to : `+1${to.replace(/\D/g, '')}`;

    console.log(`Sending SMS to ${formattedNumber} from ${twilioPhone}`);

    // Send the SMS
    const message = await client.messages.create({
      body: body,
      from: twilioPhone,
      to: formattedNumber
    });

    console.log(`SMS sent successfully, SID: ${message.sid}`);

    // Return success response
    return new Response(
      JSON.stringify({
        success: true,
        sid: message.sid,
        to: formattedNumber,
        status: message.status
      }),
      { 
        status: 200, 
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders
        } 
      }
    );
  } catch (error) {
    console.error('Error sending SMS:', error);

    // Return error response
    return new Response(
      JSON.stringify({ 
        error: 'Failed to send SMS',
        details: error.message || 'Unknown error occurred' 
      }),
      { 
        status: 500, 
        headers: { 
          'Content-Type': 'application/json',
          ...corsHeaders
        } 
      }
    );
  }
}); 