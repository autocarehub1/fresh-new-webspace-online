-- Add phone number columns for enhanced notifications

-- First check if the column already exists before adding it to avoid errors
DO $$
BEGIN
    -- Add phone_number to delivery_requests table
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'delivery_requests' 
        AND column_name = 'phone_number'
    ) THEN
        ALTER TABLE public.delivery_requests ADD COLUMN phone_number text;
        RAISE NOTICE 'Added phone_number column to delivery_requests table';
    ELSE
        RAISE NOTICE 'phone_number column already exists in delivery_requests table';
    END IF;

    -- Add phone_number to drivers table if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'drivers' 
        AND column_name = 'phone_number'
    ) THEN
        ALTER TABLE public.drivers ADD COLUMN phone_number text;
        RAISE NOTICE 'Added phone_number column to drivers table';
    ELSE
        RAISE NOTICE 'phone_number column already exists in drivers table';
    END IF;

    -- Add enable_sms_notifications column to delivery_requests
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'delivery_requests' 
        AND column_name = 'enable_sms_notifications'
    ) THEN
        ALTER TABLE public.delivery_requests ADD COLUMN enable_sms_notifications boolean DEFAULT false;
        RAISE NOTICE 'Added enable_sms_notifications column to delivery_requests table';
    ELSE
        RAISE NOTICE 'enable_sms_notifications column already exists in delivery_requests table';
    END IF;

    -- Add enable_sms_notifications column to drivers
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'drivers' 
        AND column_name = 'enable_sms_notifications'
    ) THEN
        ALTER TABLE public.drivers ADD COLUMN enable_sms_notifications boolean DEFAULT true;
        RAISE NOTICE 'Added enable_sms_notifications column to drivers table';
    ELSE
        RAISE NOTICE 'enable_sms_notifications column already exists in drivers table';
    END IF;

    -- Add notification_preferences to delivery_requests for fine-grained control
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'delivery_requests' 
        AND column_name = 'notification_preferences'
    ) THEN
        ALTER TABLE public.delivery_requests ADD COLUMN notification_preferences jsonb DEFAULT '{
            "email": true,
            "sms": false,
            "stages": {
                "approved": true,
                "picked_up": true,
                "in_transit": false,
                "out_for_delivery": true,
                "delivered": true
            }
        }'::jsonb;
        RAISE NOTICE 'Added notification_preferences column to delivery_requests table';
    ELSE
        RAISE NOTICE 'notification_preferences column already exists in delivery_requests table';
    END IF;

END $$; 