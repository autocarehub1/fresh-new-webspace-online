/**
 * Twilio Client Integration
 * Provides SMS notification capabilities for the delivery system
 */

import { DeliveryRequest } from '@/types/delivery';

// Configuration
const TWILIO_ACCOUNT_SID = process.env.NEXT_PUBLIC_TWILIO_ACCOUNT_SID || '';
const TWILIO_AUTH_TOKEN = process.env.NEXT_PUBLIC_TWILIO_AUTH_TOKEN || '';
const TWILIO_PHONE_NUMBER = process.env.NEXT_PUBLIC_TWILIO_PHONE_NUMBER || '';

// Twilio configuration state
let twilioConfig = {
  accountSid: TWILIO_ACCOUNT_SID,
  authToken: TWILIO_AUTH_TOKEN,
  phoneNumber: TWILIO_PHONE_NUMBER,
  enabled: false
};

// Helper to create consistent logging
const log = (message: string, data?: any) => {
  const prefix = '[TWILIO]';
  if (data) {
    console.log(`${prefix} ${message}`, data);
  } else {
    console.log(`${prefix} ${message}`);
  }
};

/**
 * Configure Twilio integration
 */
export const configureTwilio = (config: {
  accountSid: string;
  authToken: string;
  phoneNumber: string;
  enabled: boolean;
}) => {
  twilioConfig = {
    ...twilioConfig,
    ...config
  };
  
  log(`Twilio configured: ${twilioConfig.enabled ? 'enabled' : 'disabled'}`);
  return twilioConfig;
};

/**
 * Get current Twilio configuration
 */
export const getTwilioConfig = () => {
  return { ...twilioConfig };
};

// Environment detection for simulation
const isDevelopment = typeof window !== 'undefined' && 
  (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

/**
 * Simulated SMS response for development environments
 */
const simulateSmsResponse = (to: string, body: string) => {
  log(`[SIMULATED SMS] To: ${to}, Message: ${body}`);
  return {
    sid: `simulated-sms-${Date.now()}`,
    to,
    body,
    status: 'sent'
  };
};

/**
 * Core function to send SMS messages
 */
export async function sendSmsMessage(
  to: string,
  body: string
): Promise<any> {
  if (!twilioConfig.enabled) {
    log('Twilio is not enabled. SMS will not be sent.');
    return null;
  }
  
  log(`Preparing to send SMS to: ${to}`);
  
  // For development environment, just simulate the SMS
  if (isDevelopment) {
    log('Using simulated SMS for development environment');
    return simulateSmsResponse(to, body);
  }
  
  try {
    // In a production environment, call the Twilio API via our serverless function
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const projectId = 'joziqntfciyflfsgvsqz'; // Supabase project ID
    const baseUrl = origin.includes('localhost') || origin.includes('lovableproject.com')
      ? `https://${projectId}.supabase.co`
      : origin;
      
    const response = await fetch(`${baseUrl}/functions/v1/send-sms`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        to,
        body,
        from: twilioConfig.phoneNumber
      })
    });
    
    if (!response.ok) {
      throw new Error(`SMS API responded with ${response.status}: ${await response.text()}`);
    }
    
    const result = await response.json();
    log('SMS sent successfully:', result);
    return result;
  } catch (error) {
    log('Error sending SMS:', error);
    
    // For demo/dev purposes, return simulated response even if there's an error
    if (isDevelopment) {
      log('Falling back to simulated SMS due to error');
      return simulateSmsResponse(to, body);
    }
    
    throw error;
  }
}

/**
 * Send delivery status notification via SMS
 */
export async function sendStatusSms(
  request: DeliveryRequest,
  status: string,
  phoneNumber: string,
  note?: string
): Promise<any> {
  // Skip if no phone number is provided
  if (!phoneNumber) {
    log('No phone number provided. SMS will not be sent.');
    return null;
  }
  
  // Format the phone number if needed (simple E.164 check)
  const formattedNumber = phoneNumber.startsWith('+') 
    ? phoneNumber 
    : `+1${phoneNumber.replace(/\D/g, '')}`;
  
  // Get tracking URL
  const trackingUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}/tracking?id=${request.id || request.trackingId}`
    : `/tracking?id=${request.id || request.trackingId}`;
  
  // Create status-specific message
  let statusMessage = `Medical Courier: Your delivery ${request.id} `;
  
  switch(status.toLowerCase()) {
    case 'pending':
      statusMessage += 'has been submitted and is awaiting approval.';
      break;
    case 'in_progress':
    case 'driver assigned':
      statusMessage += 'is in progress. A driver has been assigned.';
      break;
    case 'picked_up':
    case 'picked up':
      statusMessage += 'has been picked up and is on the way.';
      break;
    case 'out for delivery':
      statusMessage += 'is out for delivery.';
      break;
    case 'delivered':
    case 'completed':
      statusMessage += 'has been delivered successfully.';
      break;
    case 'declined':
    case 'cancelled':
      statusMessage += 'has been cancelled.';
      break;
    default:
      statusMessage += `status has been updated to: ${status}`;
  }
  
  // Add custom note if provided
  if (note) {
    statusMessage += ` Note: ${note}`;
  }
  
  // Add tracking URL
  statusMessage += ` Track at: ${trackingUrl}`;
  
  // Send the SMS
  return sendSmsMessage(formattedNumber, statusMessage);
}

// Export a ready-to-use client
export default {
  sendSms: sendSmsMessage,
  sendStatusSms,
  configureTwilio,
  getTwilioConfig
}; 