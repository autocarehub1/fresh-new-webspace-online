import { DeliveryRequest } from '@/types/delivery';
import { 
  configureTwilio, 
  sendStatusSms, 
  getTwilioConfig 
} from '@/integrations/twilio/twilioClient';
import { toast } from 'sonner';
import { useState, useEffect } from 'react';

export const useSmsNotification = () => {
  const [isConfigured, setIsConfigured] = useState<boolean>(false);
  
  // Check if Twilio is configured on hook initialization
  useEffect(() => {
    try {
      const config = getTwilioConfig();
      setIsConfigured(
        config.enabled && 
        config.accountSid !== '' &&
        config.authToken !== '' &&
        config.phoneNumber !== ''
      );
    } catch (error) {
      console.error('Error checking Twilio configuration:', error);
      setIsConfigured(false);
    }
  }, []);

  /**
   * Configure Twilio integration
   */
  const configureTwilioIntegration = (
    accountSid: string,
    authToken: string,
    phoneNumber: string,
    enabled: boolean = true
  ) => {
    try {
      configureTwilio({
        accountSid,
        authToken,
        phoneNumber,
        enabled
      });
      
      setIsConfigured(true);
      toast.success('SMS notifications configured successfully');
      return true;
    } catch (error) {
      console.error('Failed to configure Twilio:', error);
      toast.error('Failed to configure SMS notifications');
      return false;
    }
  };

  /**
   * Send a status notification SMS
   */
  const sendStatusNotificationSms = async (
    request: DeliveryRequest,
    status: string,
    phoneNumber: string,
    note?: string
  ): Promise<boolean> => {
    if (!isConfigured) {
      console.warn('SMS notifications not configured. Skipping SMS.');
      return false;
    }
    
    if (!phoneNumber) {
      console.warn('No phone number provided. Skipping SMS.');
      return false;
    }
    
    try {
      const result = await sendStatusSms(request, status, phoneNumber, note);
      
      if (result) {
        console.log('Status notification SMS sent', result);
        return true;
      } else {
        console.warn('Failed to send SMS notification');
        return false;
      }
    } catch (error) {
      console.error('Error sending SMS notification:', error);
      return false;
    }
  };

  /**
   * Send a custom SMS message
   */
  const sendCustomSms = async (
    phoneNumber: string,
    message: string
  ): Promise<boolean> => {
    if (!isConfigured) {
      console.warn('SMS notifications not configured. Skipping SMS.');
      return false;
    }
    
    if (!phoneNumber) {
      console.warn('No phone number provided. Skipping SMS.');
      return false;
    }
    
    try {
      const client = await import('@/integrations/twilio/twilioClient');
      const result = await client.default.sendSms(phoneNumber, message);
      
      if (result) {
        console.log('Custom SMS sent', result);
        return true;
      } else {
        console.warn('Failed to send custom SMS');
        return false;
      }
    } catch (error) {
      console.error('Error sending custom SMS:', error);
      return false;
    }
  };

  return {
    isConfigured,
    configureTwilioIntegration,
    sendStatusNotificationSms,
    sendCustomSms
  };
}; 