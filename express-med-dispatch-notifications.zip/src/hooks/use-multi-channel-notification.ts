import { DeliveryRequest } from '@/types/delivery';
import { useNotificationEmail } from './use-notification-email';
import { useSmsNotification } from './use-sms-notification';
import { useSlackNotification } from './use-slack-notification';
import { toast } from 'sonner';

/**
 * Enhanced Multi-Channel Notification Service
 * Handles delivery notifications across email, SMS, and Slack
 */
export const useMultiChannelNotification = () => {
  const { sendStatusNotification: sendEmailNotification } = useNotificationEmail();
  const { sendStatusNotificationSms } = useSmsNotification();
  const { sendStatusUpdateNotification: sendSlackNotification } = useSlackNotification();

  /**
   * Send status notification to multiple channels
   * @param request The delivery request
   * @param status The new status
   * @param options Configuration options for notifications
   */
  const sendStatusNotification = async (
    request: DeliveryRequest, 
    status: string, 
    options: {
      sms?: boolean;
      email?: boolean;
      slack?: boolean;
      note?: string;
      phoneNumber?: string;
    } = { email: true, slack: true }
  ) => {
    const note = options.note || '';
    const results = {
      email: false,
      sms: false,
      slack: false
    };
    
    try {
      // Log initial notification attempt
      console.log(`[MULTI-CHANNEL] Sending ${status} notification for request ${request.id}`, options);
      
      // Send email notification if enabled
      if (options.email !== false) {
        try {
          await sendEmailNotification(request, status, note);
          results.email = true;
          console.log('[MULTI-CHANNEL] Email notification sent');
        } catch (error) {
          console.error('[MULTI-CHANNEL] Email notification failed:', error);
        }
      }
      
      // Send SMS notification if enabled and phone number is provided
      if (options.sms === true && options.phoneNumber) {
        try {
          const smsResult = await sendStatusNotificationSms(request, status, options.phoneNumber, note);
          results.sms = smsResult;
          console.log('[MULTI-CHANNEL] SMS notification sent:', smsResult);
        } catch (error) {
          console.error('[MULTI-CHANNEL] SMS notification failed:', error);
        }
      }
      
      // Send Slack notification if enabled
      if (options.slack !== false) {
        try {
          const slackResult = await sendSlackNotification(request, status, note);
          results.slack = slackResult;
          console.log('[MULTI-CHANNEL] Slack notification sent:', slackResult);
        } catch (error) {
          console.error('[MULTI-CHANNEL] Slack notification failed:', error);
        }
      }
      
      // Determine success based on which channels succeeded
      const successChannels = Object.entries(results)
        .filter(([_, succeeded]) => succeeded)
        .map(([channel]) => channel);
      
      if (successChannels.length > 0) {
        console.log(`[MULTI-CHANNEL] Notifications sent on channels: ${successChannels.join(', ')}`);
        toast.success(`Status notification sent via ${successChannels.join(', ')}`);
        return true;
      } else {
        console.warn('[MULTI-CHANNEL] All notification channels failed');
        toast.error('Failed to send notifications on all channels');
        return false;
      }
    } catch (error) {
      console.error('[MULTI-CHANNEL] Error in notification process:', error);
      toast.error('Error sending notifications');
      return false;
    }
  };
  
  /**
   * Send customer notifications for a specific delivery stage
   */
  const sendDeliveryStageNotification = async (
    request: DeliveryRequest,
    stage: 'pending' | 'approved' | 'picked_up' | 'in_transit' | 'out_for_delivery' | 'delivered' | 'cancelled',
    options: {
      note?: string;
      phoneNumber?: string;
    } = {}
  ) => {
    // Define stage-specific status and notes
    let status: string;
    let defaultNote: string;
    
    switch (stage) {
      case 'pending':
        status = 'pending';
        defaultNote = 'Your delivery request has been received and is pending approval.';
        break;
      case 'approved':
        status = 'in_progress';
        defaultNote = 'Your delivery request has been approved and a driver will be assigned soon.';
        break;
      case 'picked_up':
        status = 'picked_up';
        defaultNote = 'Your package has been picked up and is on its way.';
        break;
      case 'in_transit':
        status = 'in_transit';
        defaultNote = 'Your package is in transit to its destination.';
        break;
      case 'out_for_delivery':
        status = 'out_for_delivery';
        defaultNote = 'Your package is out for delivery and will arrive soon.';
        break;
      case 'delivered':
        status = 'delivered';
        defaultNote = 'Your package has been delivered successfully.';
        break;
      case 'cancelled':
        status = 'cancelled';
        defaultNote = 'Your delivery has been cancelled.';
        break;
      default:
        status = stage;
        defaultNote = `Your delivery status has been updated to: ${stage}`;
    }
    
    // Use provided note or default
    const note = options.note || defaultNote;
    
    // Send through multiple channels
    return sendStatusNotification(request, status, {
      email: true,
      sms: !!options.phoneNumber,
      slack: true,
      note,
      phoneNumber: options.phoneNumber
    });
  };
  
  /**
   * Send driver notifications for a specific delivery
   */
  const sendDriverNotification = async (
    request: DeliveryRequest,
    message: string,
    driverPhone: string
  ) => {
    if (!driverPhone) {
      console.warn('[MULTI-CHANNEL] No driver phone provided for notification');
      return false;
    }
    
    try {
      // Send SMS to driver
      const { sendCustomSms } = useSmsNotification();
      const result = await sendCustomSms(driverPhone, message);
      
      if (result) {
        console.log('[MULTI-CHANNEL] Driver notification sent via SMS');
        return true;
      } else {
        console.warn('[MULTI-CHANNEL] Failed to send driver notification');
        return false;
      }
    } catch (error) {
      console.error('[MULTI-CHANNEL] Error sending driver notification:', error);
      return false;
    }
  };

  return {
    sendStatusNotification,
    sendDeliveryStageNotification,
    sendDriverNotification
  };
}; 