import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { useSmsNotification } from '@/hooks/use-sms-notification';
import { toast } from 'sonner';
import { useMultiChannelNotification } from '@/hooks/use-multi-channel-notification';
import { RefreshCw, Send, Phone, Settings, Check, AlertTriangle } from 'lucide-react';

const SmsIntegrationCard = () => {
  const [accountSid, setAccountSid] = useState('');
  const [authToken, setAuthToken] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [enabled, setEnabled] = useState(false);
  const [testPhone, setTestPhone] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'success' | 'error'>('idle');
  
  const { isConfigured, configureTwilioIntegration, sendCustomSms } = useSmsNotification();
  const { sendDeliveryStageNotification } = useMultiChannelNotification();
  
  // Initialize from saved settings if available
  useEffect(() => {
    const loadSettings = () => {
      const savedSettings = localStorage.getItem('twilio_settings');
      if (savedSettings) {
        try {
          const settings = JSON.parse(savedSettings);
          setAccountSid(settings.accountSid || '');
          setAuthToken(settings.authToken || '');
          setPhoneNumber(settings.phoneNumber || '');
          setEnabled(settings.enabled !== false);
          
          // Configure Twilio with saved settings
          if (settings.accountSid && settings.authToken && settings.phoneNumber) {
            configureTwilioIntegration(
              settings.accountSid,
              settings.authToken,
              settings.phoneNumber,
              settings.enabled !== false
            );
          }
        } catch (error) {
          console.error('Error loading Twilio settings:', error);
        }
      }
    };
    
    loadSettings();
  }, [configureTwilioIntegration]);
  
  const handleSaveSettings = async () => {
    setIsSaving(true);
    
    try {
      // Validate settings
      if (!accountSid || !authToken || !phoneNumber) {
        toast.error('Please fill in all required fields');
        setIsSaving(false);
        return;
      }
      
      // Save to local storage for persistence
      const settings = {
        accountSid,
        authToken,
        phoneNumber,
        enabled
      };
      
      localStorage.setItem('twilio_settings', JSON.stringify(settings));
      
      // Configure Twilio
      const success = configureTwilioIntegration(
        accountSid,
        authToken,
        phoneNumber,
        enabled
      );
      
      if (success) {
        toast.success('SMS notification settings saved successfully');
        setConnectionStatus('success');
      } else {
        toast.error('Failed to configure SMS notifications');
        setConnectionStatus('error');
      }
    } catch (error) {
      console.error('Error saving SMS settings:', error);
      toast.error('Error saving settings');
      setConnectionStatus('error');
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleTestSms = async () => {
    if (!testPhone) {
      toast.error('Please enter a phone number for testing');
      return;
    }
    
    setIsTesting(true);
    setConnectionStatus('idle');
    
    try {
      const message = `This is a test message from your Medical Dispatch system. Time: ${new Date().toLocaleTimeString()}`;
      const success = await sendCustomSms(testPhone, message);
      
      if (success) {
        toast.success('Test SMS sent successfully');
        setConnectionStatus('success');
      } else {
        toast.error('Failed to send test SMS');
        setConnectionStatus('error');
      }
    } catch (error) {
      console.error('Error testing SMS integration:', error);
      setConnectionStatus('error');
      toast.error(`Failed to send test message: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsTesting(false);
    }
  };
  
  // Function to test different notification stages
  const testNotificationStage = async (stage: string) => {
    if (!testPhone) {
      toast.error('Please enter a phone number for testing');
      return;
    }
    
    setIsTesting(true);
    
    try {
      // Create a sample delivery request for testing
      const sampleRequest = {
        id: `TEST-${Math.floor(Math.random() * 10000)}`,
        pickup_location: 'Memorial Hospital',
        delivery_location: 'Central Medical Center',
        status: 'pending',
        priority: 'high',
        packageType: 'Medical Samples',
        distance: 5.2,
        trackingId: `TRK-${Math.floor(Math.random() * 10000)}`,
      };
      
      // Convert stage string to appropriate type
      const notificationStage = stage as 'pending' | 'approved' | 'picked_up' | 'in_transit' | 'out_for_delivery' | 'delivered' | 'cancelled';
      
      const success = await sendDeliveryStageNotification(sampleRequest, notificationStage, {
        note: `This is a test ${stage} notification.`,
        phoneNumber: testPhone
      });
      
      if (success) {
        toast.success(`Test ${stage} notification sent successfully`);
      } else {
        toast.error(`Failed to send ${stage} notification`);
      }
    } catch (error) {
      console.error('Error testing notification:', error);
      toast.error('Error during test: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsTesting(false);
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Phone className="mr-2 h-5 w-5" />
          SMS Notification Settings
        </CardTitle>
        <CardDescription>
          Configure Twilio SMS integration for customer and driver notifications
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Switch 
              id="sms-enabled" 
              checked={enabled}
              onCheckedChange={setEnabled}
            />
            <Label htmlFor="sms-enabled" className="font-medium">Enable SMS notifications</Label>
          </div>
          <div className="flex items-center space-x-2">
            {connectionStatus === 'success' && (
              <div className="flex items-center text-green-600">
                <Check className="w-4 h-4 mr-1" />
                <span className="text-sm">Connected</span>
              </div>
            )}
            {connectionStatus === 'error' && (
              <div className="flex items-center text-red-600">
                <AlertTriangle className="w-4 h-4 mr-1" />
                <span className="text-sm">Connection failed</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="account-sid">Twilio Account SID</Label>
            <Input
              id="account-sid"
              value={accountSid}
              onChange={(e) => setAccountSid(e.target.value)}
              placeholder="AC1234567890abcdef1234567890abcdef"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="auth-token">Twilio Auth Token</Label>
            <Input
              id="auth-token"
              type="password"
              value={authToken}
              onChange={(e) => setAuthToken(e.target.value)}
              placeholder="Your Twilio auth token"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="phone-number">Twilio Phone Number</Label>
            <Input
              id="phone-number"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="+15555555555"
            />
            <p className="text-xs text-gray-500">Format: +1XXXXXXXXXX (E.164 format)</p>
          </div>
        </div>
        
        <Separator />
        
        <div className="space-y-4">
          <h3 className="text-md font-medium">Test SMS Integration</h3>
          
          <div className="flex space-x-2">
            <div className="flex-grow">
              <Input
                id="test-phone"
                value={testPhone}
                onChange={(e) => setTestPhone(e.target.value)}
                placeholder="Enter phone number for testing"
              />
            </div>
            <Button 
              onClick={handleTestSms} 
              disabled={isTesting}
              variant="outline"
            >
              {isTesting ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4 mr-1" />}
              {isTesting ? 'Sending...' : 'Test'}
            </Button>
          </div>
          
          <div className="grid grid-cols-3 gap-2">
            <Button 
              size="sm"
              variant="outline"
              onClick={() => testNotificationStage('approved')}
              disabled={isTesting}
            >
              Approved
            </Button>
            <Button 
              size="sm"
              variant="outline"
              onClick={() => testNotificationStage('picked_up')}
              disabled={isTesting}
            >
              Picked Up
            </Button>
            <Button 
              size="sm"
              variant="outline"
              onClick={() => testNotificationStage('delivered')}
              disabled={isTesting}
            >
              Delivered
            </Button>
          </div>
          
          <p className="text-xs text-gray-500">These tests will send actual SMS messages. Standard rates apply.</p>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={() => window.open('https://www.twilio.com/console', '_blank')}>
          <Settings className="h-4 w-4 mr-1" />
          Twilio Console
        </Button>
        <Button onClick={handleSaveSettings} disabled={isSaving}>
          {isSaving ? <RefreshCw className="h-4 w-4 animate-spin mr-1" /> : null}
          {isSaving ? 'Saving...' : 'Save Settings'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default SmsIntegrationCard; 